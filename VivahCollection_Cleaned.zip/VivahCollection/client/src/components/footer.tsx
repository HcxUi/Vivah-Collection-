import { Link } from "wouter";
import { Leaf, Phone, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FaInstagram, FaFacebook, FaPinterest, FaYoutube } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Newsletter Section */}
      <div className="bg-burgundy py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-playfair font-bold text-white mb-4">
            Stay Updated
          </h2>
          <p className="text-white/90 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter and be the first to know about new collections, 
            exclusive offers, and bridal fashion tips.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              className="flex-1 bg-white text-gray-800 border-none"
            />
            <Button className="bg-gold text-white hover:bg-white hover:text-gold">
              Subscribe
            </Button>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 gradient-burgundy-gold rounded-full flex items-center justify-center">
                  <Leaf className="text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-playfair font-bold">Vivah Collection</h3>
                  <p className="text-sm text-gold font-dancing">Indian Bridal Sarees</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Creating magical moments for brides with our exquisite collection of 
                traditional Indian bridal wear.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/" className="text-gray-400 hover:text-gold transition-colors">Home</Link></li>
                <li><Link href="/products/bridal-sarees" className="text-gray-400 hover:text-gold transition-colors">Sarees</Link></li>
                <li><Link href="/products/jewelry" className="text-gray-400 hover:text-gold transition-colors">Jewelry</Link></li>
                <li><Link href="/products/accessories" className="text-gray-400 hover:text-gold transition-colors">Accessories</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-gold transition-colors">Custom Orders</Link></li>
              </ul>
            </div>

            {/* Customer Service */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Customer Service</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Size Guide</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Shipping Info</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Returns & Exchanges</a></li>
                <li><a href="#" className="text-gray-400 hover:text-gold transition-colors">Care Instructions</a></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-gold transition-colors">Contact Us</Link></li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-3 text-sm">
                <div className="flex items-center space-x-3">
                  <Phone className="text-gold w-4 h-4" />
                  <span className="text-gray-400">+91 98765 43210</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="text-gold w-4 h-4" />
                  <span className="text-gray-400">info@vivahcollection.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="text-gold w-4 h-4" />
                  <span className="text-gray-400">Mumbai, India</span>
                </div>
              </div>
              <div className="flex space-x-4 mt-6">
                <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                  <FaInstagram className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                  <FaFacebook className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                  <FaPinterest className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                  <FaYoutube className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p className="text-gray-400 text-sm">
              © 2024 Vivah Collection. All rights reserved. | Privacy Policy | Terms of Service
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
