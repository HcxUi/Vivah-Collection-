import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="relative gradient-burgundy-rose py-20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="text-center md:text-left">
            <h2 className="text-5xl md:text-6xl font-playfair font-bold text-white mb-6">
              Exquisite<br />
              <span className="text-gold font-dancing">Bridal</span><br />
              Sarees
            </h2>
            <p className="text-lg text-white/90 mb-8 leading-relaxed">
              Discover our curated collection of traditional Indian bridal sarees, jewelry, and accessories. 
              Each piece is carefully selected to make your special day unforgettable.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/products">
                <Button className="bg-white text-burgundy hover:bg-gold hover:text-white transition-all transform hover:scale-105">
                  Shop Collection
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-burgundy transition-all">
                  Custom Orders
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=400&fit=crop"
              alt="Beautiful bridal saree collection"
              className="rounded-2xl shadow-2xl w-full h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-burgundy/30 to-transparent rounded-2xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
