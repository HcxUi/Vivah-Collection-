export const productImages = {
  // Bridal Sarees
  'royal-red-silk-saree': [
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&brightness=1.1',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&brightness=1.1'
  ],
  
  'maroon-embroidered-saree': [
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=320',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=320',
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=320&brightness=1.1',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=320&brightness=1.1'
  ],
  
  'emerald-green-silk-saree': [
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=120',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=120',
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=120&brightness=1.1',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=120&brightness=1.1'
  ],
  
  'pink-silk-saree': [
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=300',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=300',
    'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=300&brightness=1.1',
    'https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=300&brightness=1.1'
  ],
  
  // Jewelry
  'golden-necklace-set': [
    'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop&brightness=1.1',
    'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=600&fit=crop&brightness=1.1'
  ],
  
  'diamond-earrings': [
    'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop&contrast=1.2',
    'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=600&fit=crop&contrast=1.2',
    'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop&contrast=1.2&brightness=1.1',
    'https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=600&fit=crop&contrast=1.2&brightness=1.1'
  ],
  
  // Accessories
  'bridal-accessories-set': [
    'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1609794995011-6f7e5ccb1e7e?w=800&h=600&fit=crop',
    'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&h=600&fit=crop&brightness=1.1',
    'https://images.unsplash.com/photo-1609794995011-6f7e5ccb1e7e?w=800&h=600&fit=crop&brightness=1.1'
  ],
  
  'traditional-bangles-set': [
    'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&h=600&fit=crop&brightness=1.1',
    'https://images.unsplash.com/photo-1609794995011-6f7e5ccb1e7e?w=800&h=600&fit=crop&brightness=1.1',
    'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&h=600&fit=crop&brightness=1.2',
    'https://images.unsplash.com/photo-1609794995011-6f7e5ccb1e7e?w=800&h=600&fit=crop&brightness=1.2'
  ]
};
