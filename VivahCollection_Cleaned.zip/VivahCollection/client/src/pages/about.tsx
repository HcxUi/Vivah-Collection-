import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Users, Award, Sparkles } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-cream">
      {/* Hero Section */}
      <section className="gradient-burgundy-rose py-20">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-5xl font-playfair font-bold text-white mb-6">
              Our Story
            </h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Two decades of creating magical moments for brides across India
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        {/* Main Story */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-4xl font-playfair font-bold text-gray-800 mb-6">
              Creating Dreams Since 2004
            </h2>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Vivah Collection was born from a simple belief: every bride deserves to feel like royalty 
              on her special day. Founded by Mrs. Priya Agarwal, a passionate lover of Indian textiles 
              and traditional craftsmanship, our journey began in a small boutique in Mumbai.
            </p>
            <p className="text-gray-600 mb-6 leading-relaxed">
              What started as a dream to preserve and celebrate India's rich textile heritage has grown 
              into one of the most trusted names in bridal wear. Today, we work directly with skilled 
              artisans across India, ensuring that every piece in our collection tells a story of 
              tradition, elegance, and timeless beauty.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Our curated collection features everything from traditional Banarasi silks to contemporary 
              designer pieces, each handpicked for its quality, craftsmanship, and ability to make every 
              bride feel extraordinary.
            </p>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&h=400&fit=crop"
              alt="Traditional textile craftsmanship"
              className="rounded-2xl shadow-xl w-full h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-burgundy/20 to-transparent rounded-2xl"></div>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid md:grid-cols-4 gap-8 mb-20">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-16 h-16 gradient-burgundy-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-burgundy mb-2">500+</div>
              <div className="text-sm text-gray-600">Happy Brides</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-16 h-16 gradient-burgundy-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-burgundy mb-2">20+</div>
              <div className="text-sm text-gray-600">Years Experience</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-16 h-16 gradient-burgundy-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-burgundy mb-2">1000+</div>
              <div className="text-sm text-gray-600">Unique Pieces</div>
            </CardContent>
          </Card>
          
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="w-16 h-16 gradient-burgundy-gold rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-burgundy mb-2">15+</div>
              <div className="text-sm text-gray-600">Awards Won</div>
            </CardContent>
          </Card>
        </div>

        {/* Our Mission */}
        <div className="bg-white rounded-2xl p-8 mb-20">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-playfair font-bold text-gray-800 mb-4">
              Our Mission
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We are dedicated to preserving India's textile heritage while creating unforgettable 
              experiences for modern brides.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-burgundy/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-10 h-10 text-burgundy" />
              </div>
              <h3 className="text-xl font-playfair font-semibold text-gray-800 mb-2">
                Authentic Craftsmanship
              </h3>
              <p className="text-gray-600 text-sm">
                Every piece is handcrafted by skilled artisans using traditional techniques 
                passed down through generations.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-10 h-10 text-gold" />
              </div>
              <h3 className="text-xl font-playfair font-semibold text-gray-800 mb-2">
                Timeless Elegance
              </h3>
              <p className="text-gray-600 text-sm">
                Our designs blend traditional Indian aesthetics with contemporary sensibilities 
                for the modern bride.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-copper/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-10 h-10 text-copper" />
              </div>
              <h3 className="text-xl font-playfair font-semibold text-gray-800 mb-2">
                Exceptional Quality
              </h3>
              <p className="text-gray-600 text-sm">
                We source only the finest materials and ensure the highest quality standards 
                in every piece we create.
              </p>
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="grid md:grid-cols-2 gap-8 mb-20">
          <Card>
            <CardContent className="p-8">
              <h3 className="text-2xl font-playfair font-bold text-gray-800 mb-4">
                Our Values
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Badge className="bg-burgundy">1</Badge>
                  <div>
                    <h4 className="font-semibold text-gray-800">Authenticity</h4>
                    <p className="text-sm text-gray-600">
                      Every piece reflects genuine Indian craftsmanship and heritage
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Badge className="bg-gold">2</Badge>
                  <div>
                    <h4 className="font-semibold text-gray-800">Quality</h4>
                    <p className="text-sm text-gray-600">
                      We never compromise on materials or craftsmanship
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Badge className="bg-copper">3</Badge>
                  <div>
                    <h4 className="font-semibold text-gray-800">Customer Satisfaction</h4>
                    <p className="text-sm text-gray-600">
                      Every bride's happiness is our ultimate goal
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-8">
              <h3 className="text-2xl font-playfair font-bold text-gray-800 mb-4">
                Why Choose Us?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Badge className="bg-burgundy">✓</Badge>
                  <div>
                    <h4 className="font-semibold text-gray-800">Curated Collection</h4>
                    <p className="text-sm text-gray-600">
                      Each piece is carefully selected for its uniqueness and quality
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Badge className="bg-gold">✓</Badge>
                  <div>
                    <h4 className="font-semibold text-gray-800">Personal Service</h4>
                    <p className="text-sm text-gray-600">
                      Dedicated consultation to help you find the perfect outfit
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Badge className="bg-copper">✓</Badge>
                  <div>
                    <h4 className="font-semibold text-gray-800">Custom Orders</h4>
                    <p className="text-sm text-gray-600">
                      Bespoke designs tailored to your specific preferences
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Team */}
        <div className="text-center">
          <h2 className="text-4xl font-playfair font-bold text-gray-800 mb-6">
            Meet Our Founder
          </h2>
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardContent className="p-8">
                <div className="w-32 h-32 gradient-burgundy-gold rounded-full mx-auto mb-6 flex items-center justify-center">
                  <span className="text-4xl font-playfair font-bold text-white">PA</span>
                </div>
                <h3 className="text-2xl font-playfair font-bold text-gray-800 mb-2">
                  Mrs. Priya Agarwal
                </h3>
                <p className="text-gold font-dancing text-lg mb-4">Founder & Creative Director</p>
                <p className="text-gray-600 leading-relaxed">
                  With over 20 years of experience in the textile industry, Mrs. Agarwal has dedicated 
                  her life to preserving and celebrating India's rich heritage of traditional craftsmanship. 
                  Her passion for authentic Indian textiles and commitment to quality has made Vivah Collection 
                  a trusted name among brides across the country.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
