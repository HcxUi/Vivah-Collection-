import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Phone, Mail, MapPin, Clock, Send, MessageCircle } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
    inquiryType: "general"
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));

    toast({
      title: "Message Sent Successfully!",
      description: "Thank you for contacting us. We'll get back to you within 24 hours.",
    });

    // Reset form
    setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
      inquiryType: "general"
    });

    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Hero Section */}
      <section className="gradient-burgundy-rose py-20">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-5xl font-playfair font-bold text-white mb-6">
              Contact Us
            </h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              We'd love to hear from you. Send us a message and we'll respond as soon as possible.
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl font-playfair text-gray-800">
                Send us a Message
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <Input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      placeholder="Your full name"
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <Input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      placeholder="your@email.com"
                      className="w-full"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <Input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+91 98765 43210"
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Inquiry Type
                    </label>
                    <select
                      name="inquiryType"
                      value={formData.inquiryType}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-burgundy focus:border-transparent"
                    >
                      <option value="general">General Inquiry</option>
                      <option value="custom">Custom Order</option>
                      <option value="appointment">Book Appointment</option>
                      <option value="support">Customer Support</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject *
                  </label>
                  <Input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    placeholder="How can we help you?"
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message *
                  </label>
                  <Textarea
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    placeholder="Tell us about your requirements, preferred styles, budget, or any other details..."
                    className="w-full"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-burgundy hover:bg-gold text-white flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      Send Message
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            {/* Contact Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-playfair text-gray-800">
                  Get in Touch
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-burgundy/10 rounded-full flex items-center justify-center">
                    <Phone className="w-6 h-6 text-burgundy" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Phone</h3>
                    <p className="text-gray-600">+91 98765 43210</p>
                    <p className="text-gray-600">+91 98765 43211</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center">
                    <Mail className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Email</h3>
                    <p className="text-gray-600">info@vivahcollection.com</p>
                    <p className="text-gray-600">orders@vivahcollection.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-copper/10 rounded-full flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-copper" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Visit Our Showroom</h3>
                    <p className="text-gray-600">
                      123 Fashion Street, Linking Road<br />
                      Bandra West, Mumbai - 400050<br />
                      Maharashtra, India
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-rose/20 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-burgundy" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Business Hours</h3>
                    <p className="text-gray-600">
                      Monday - Saturday: 10:00 AM - 8:00 PM<br />
                      Sunday: 11:00 AM - 6:00 PM
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Services */}
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-playfair text-gray-800">
                  Our Services
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-burgundy text-white">1</Badge>
                    <span className="text-gray-700">Personal Bridal Consultation</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-gold text-white">2</Badge>
                    <span className="text-gray-700">Custom Saree Design</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-copper text-white">3</Badge>
                    <span className="text-gray-700">Jewelry Matching Service</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-rose text-gray-800">4</Badge>
                    <span className="text-gray-700">Alteration & Fitting</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-burgundy text-white">5</Badge>
                    <span className="text-gray-700">Home Consultation</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* FAQ */}
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-playfair text-gray-800 flex items-center gap-2">
                  <MessageCircle className="w-6 h-6" />
                  Quick Questions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Do you take custom orders?</h4>
                  <p className="text-sm text-gray-600">
                    Yes! We specialize in custom bridal wear. Contact us to discuss your requirements.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">How long does delivery take?</h4>
                  <p className="text-sm text-gray-600">
                    Standard delivery takes 3-5 business days. Custom orders may take 2-4 weeks.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Do you offer trial sessions?</h4>
                  <p className="text-sm text-gray-600">
                    Yes, we offer trial sessions by appointment. Please call to schedule.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <Card className="mt-16">
          <CardHeader>
            <CardTitle className="text-2xl font-playfair text-gray-800">
              Find Us
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-100 rounded-lg p-8 text-center">
              <MapPin className="w-16 h-16 text-burgundy mx-auto mb-4" />
              <h3 className="text-xl font-playfair font-semibold text-gray-800 mb-2">
                Visit Our Showroom
              </h3>
              <p className="text-gray-600 mb-4">
                Experience our complete collection in person at our Mumbai showroom
              </p>
              <Button className="bg-burgundy hover:bg-gold text-white">
                Get Directions
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
