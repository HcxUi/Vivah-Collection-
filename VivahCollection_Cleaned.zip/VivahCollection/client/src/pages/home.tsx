import { useQuery } from "@tanstack/react-query";
import HeroSection from "@/components/hero-section";
import CategoryGrid from "@/components/category-grid";
import ProductCard from "@/components/product-card";
import Testimonials from "@/components/testimonials";
import Newsletter from "@/components/newsletter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { Product } from "@shared/schema";

export default function Home() {
  const { data: featuredProducts, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', { featured: true }],
    queryFn: async () => {
      const response = await fetch('/api/products?featured=true');
      if (!response.ok) throw new Error('Failed to fetch featured products');
      return response.json();
    },
  });

  return (
    <div>
      <HeroSection />
      <CategoryGrid />
      
      {/* Featured Products */}
      <section className="py-16 bg-rose">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-playfair font-bold text-gray-800 mb-4">
              Featured Collection
            </h2>
            <p className="text-gray-600">Handpicked pieces for the discerning bride</p>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-80 w-full rounded-2xl" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/products">
              <Button className="bg-burgundy text-white hover:bg-gold transition-colors">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-playfair font-bold text-gray-800 mb-6">
                Our Story
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Vivah Collection has been creating magical moments for brides across India for over two decades. 
                We believe every bride deserves to feel like royalty on her special day, and our curated collection 
                of exquisite sarees, jewelry, and accessories reflects this philosophy.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                From traditional Banarasi silks to contemporary designer pieces, each item in our collection 
                is handpicked for its quality, craftsmanship, and timeless beauty. We work directly with skilled 
                artisans to bring you authentic pieces that celebrate India's rich textile heritage.
              </p>
              <div className="grid grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-burgundy mb-2">500+</div>
                  <div className="text-sm text-gray-600">Happy Brides</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-burgundy mb-2">20+</div>
                  <div className="text-sm text-gray-600">Years Experience</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-burgundy mb-2">1000+</div>
                  <div className="text-sm text-gray-600">Unique Pieces</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&h=400&fit=crop"
                alt="Traditional textile craftsmanship"
                className="rounded-2xl shadow-xl w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-burgundy/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      <Testimonials />
      <Newsletter />
    </div>
  );
}
