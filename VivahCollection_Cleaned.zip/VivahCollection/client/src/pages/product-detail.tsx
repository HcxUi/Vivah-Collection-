import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, Heart, Share2, Truck, ShieldCheck, RotateCcw } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

export default function ProductDetail() {
  const params = useParams();
  const slug = params.slug;
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((state) => state.addItem);
  const { toast } = useToast();

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: ['/api/products', slug],
    queryFn: async () => {
      const response = await fetch(`/api/products/${slug}`);
      if (!response.ok) throw new Error('Product not found');
      return response.json();
    },
  });

  const handleAddToCart = () => {
    if (!product) return;

    const cartItem = {
      id: Date.now(),
      productId: product.id,
      quantity,
      product: {
        id: product.id,
        name: product.name,
        price: product.price,
        images: product.images || [],
        slug: product.slug,
      },
    };

    addItem(cartItem);
    toast({
      title: "Added to Cart",
      description: `${quantity} x ${product.name} added to your cart.`,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-cream">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-6 w-32 mb-8" />
          <div className="grid lg:grid-cols-2 gap-12">
            <Skeleton className="h-96 w-full rounded-2xl" />
            <div className="space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-1/2" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-cream flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Product not found</h1>
          <Link href="/products">
            <Button>Browse Products</Button>
          </Link>
        </div>
      </div>
    );
  }

  const originalPrice = product.originalPrice ? parseFloat(product.originalPrice) : null;
  const currentPrice = parseFloat(product.price);
  const discount = originalPrice ? Math.round(((originalPrice - currentPrice) / originalPrice) * 100) : null;

  return (
    <div className="min-h-screen bg-cream">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-8">
          <Link href="/products" className="flex items-center gap-2 text-gray-600 hover:text-burgundy">
            <ChevronLeft className="w-4 h-4" />
            Back to Products
          </Link>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative overflow-hidden rounded-2xl">
              <img
                src={product.images?.[selectedImageIndex] || "/placeholder.jpg"}
                alt={product.name}
                className="w-full h-96 lg:h-[500px] object-cover"
              />
              {discount && (
                <Badge className="absolute top-4 left-4 bg-burgundy text-white">
                  {discount}% OFF
                </Badge>
              )}
            </div>
            
            {/* Thumbnail Images */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImageIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImageIndex === index ? 'border-burgundy' : 'border-gray-200'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} view ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-playfair font-bold text-gray-800 mb-2">
                {product.name}
              </h1>
              <p className="text-gray-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-burgundy">
                  ₹{currentPrice.toLocaleString()}
                </span>
                {originalPrice && (
                  <span className="text-lg text-gray-500 line-through">
                    ₹{originalPrice.toLocaleString()}
                  </span>
                )}
              </div>
              {discount && (
                <Badge className="bg-green-100 text-green-800">
                  Save ₹{(originalPrice! - currentPrice).toLocaleString()}
                </Badge>
              )}
            </div>

            {/* Product Details */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              {product.fabric && (
                <div>
                  <span className="font-medium text-gray-700">Fabric:</span>
                  <p className="text-gray-600">{product.fabric}</p>
                </div>
              )}
              {product.color && (
                <div>
                  <span className="font-medium text-gray-700">Color:</span>
                  <p className="text-gray-600">{product.color}</p>
                </div>
              )}
              {product.size && (
                <div>
                  <span className="font-medium text-gray-700">Size:</span>
                  <p className="text-gray-600">{product.size}</p>
                </div>
              )}
              <div>
                <span className="font-medium text-gray-700">Availability:</span>
                <p className={`${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </p>
              </div>
            </div>

            {/* Quantity & Add to Cart */}
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <label className="font-medium text-gray-700">Quantity:</label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    -
                  </Button>
                  <span className="w-12 text-center">{quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    +
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleAddToCart}
                  disabled={!product.inStock}
                  className="flex-1 bg-burgundy hover:bg-gold text-white"
                >
                  Add to Cart
                </Button>
                <Button variant="outline" size="icon" className="hover:text-burgundy">
                  <Heart className="w-5 h-5" />
                </Button>
                <Button variant="outline" size="icon" className="hover:text-burgundy">
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Service Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                <Truck className="w-5 h-5 text-burgundy" />
                <div>
                  <p className="font-medium text-sm">Free Shipping</p>
                  <p className="text-xs text-gray-500">On orders over ₹50,000</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                <ShieldCheck className="w-5 h-5 text-burgundy" />
                <div>
                  <p className="font-medium text-sm">Authentic</p>
                  <p className="text-xs text-gray-500">100% genuine products</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
                <RotateCcw className="w-5 h-5 text-burgundy" />
                <div>
                  <p className="font-medium text-sm">Easy Returns</p>
                  <p className="text-xs text-gray-500">7-day return policy</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mt-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="care">Care Instructions</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="prose max-w-none">
                    <p className="text-gray-600 leading-relaxed">
                      {product.description}
                    </p>
                    <h3 className="text-lg font-playfair font-semibold mt-6 mb-3">
                      Product Features
                    </h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      <li>Premium quality materials and craftsmanship</li>
                      <li>Traditional designs with modern elegance</li>
                      <li>Perfect for weddings and special occasions</li>
                      <li>Handcrafted by skilled artisans</li>
                      <li>Authentic Indian textile heritage</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="specifications" className="mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-3">Product Details</h3>
                      <div className="space-y-2 text-sm">
                        {product.fabric && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Fabric:</span>
                            <span className="font-medium">{product.fabric}</span>
                          </div>
                        )}
                        {product.color && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Color:</span>
                            <span className="font-medium">{product.color}</span>
                          </div>
                        )}
                        {product.size && (
                          <div className="flex justify-between">
                            <span className="text-gray-600">Size:</span>
                            <span className="font-medium">{product.size}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-gray-600">Weight:</span>
                          <span className="font-medium">1.5 kg</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Origin:</span>
                          <span className="font-medium">India</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-3">Dimensions</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Length:</span>
                          <span className="font-medium">5.5 meters</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Width:</span>
                          <span className="font-medium">1.2 meters</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Blouse:</span>
                          <span className="font-medium">0.8 meters</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="care" className="mt-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-3">Care Instructions</h3>
                      <p className="text-gray-600 mb-4">
                        {product.careInstructions || "Dry clean only"}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2">Additional Care Tips:</h4>
                      <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                        <li>Store in a cool, dry place away from direct sunlight</li>
                        <li>Avoid contact with perfumes, cosmetics, and chemicals</li>
                        <li>Iron on low heat with a cloth barrier</li>
                        <li>Keep jewelry separately to avoid snagging</li>
                        <li>Air dry in shade, avoid direct sunlight</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
