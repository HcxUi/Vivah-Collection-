# Vivah Collection - Indian Bridal Sarees E-commerce Platform

## Overview

This is a full-stack e-commerce web application for selling traditional Indian bridal sarees, jewelry, and accessories. The application features a modern React frontend with a Node.js/Express backend, using PostgreSQL for data storage and a component-based architecture built with shadcn/ui.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **State Management**: 
  - Zustand for cart state management with persistence
  - TanStack Query for server state management
- **Build Tool**: Vite with React plugin
- **Package Manager**: npm

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Style**: RESTful API with JSON responses
- **Development**: Hot reload with Vite middleware integration

### Key Components

#### Database Schema
- **Categories**: Product categories (bridal-sarees, jewelry, accessories)
- **Products**: Main product catalog with pricing, images, and metadata
- **Cart Items**: Session-based shopping cart storage
- **Testimonials**: Customer reviews and ratings
- **Orders**: Customer order management with status tracking
- **Order Items**: Individual items within orders
- **Contact Requests**: Customer inquiries and support requests
- **Admin Users**: Administrative user accounts with role-based access

#### Frontend Components
- **Layout**: Header with navigation, footer with newsletter signup
- **Product Display**: Product cards, detail pages, category grids
- **Shopping Cart**: Persistent cart with local storage
- **Admin Panel**: Complete admin dashboard with authentication
- **UI Components**: Comprehensive design system with buttons, forms, modals, etc.

#### Backend Services
- **Storage Layer**: Abstract storage interface with in-memory implementation
- **API Routes**: RESTful endpoints for categories, products, cart, testimonials, orders, and contact requests
- **Admin API**: Secure admin endpoints for managing orders, products, and customer inquiries
- **Authentication**: Simple token-based admin authentication
- **Session Management**: Session-based cart tracking

### Data Flow

1. **Product Browsing**: Frontend fetches categories and products via REST API
2. **Cart Management**: Client-side cart state synced with backend sessions
3. **Product Search**: Client-side filtering with server-side data
4. **Order Processing**: Cart items processed through backend API

### External Dependencies

#### Frontend Dependencies
- **UI/UX**: Radix UI primitives, React Hook Form, date-fns
- **Data Fetching**: TanStack Query for caching and synchronization
- **Styling**: Tailwind CSS with class-variance-authority for variants
- **Icons**: Lucide React icons, React Icons for social media

#### Backend Dependencies
- **Database**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod for schema validation
- **Development**: tsx for TypeScript execution, esbuild for production builds

### Deployment Strategy

#### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution with nodemon-like behavior
- **Database**: Drizzle Kit for migrations and schema management

#### Production
- **Frontend**: Static build output to `dist/public`
- **Backend**: esbuild bundle to `dist/index.js`
- **Database**: PostgreSQL via Neon Database connection
- **Environment**: NODE_ENV-based configuration

#### Build Process
1. Frontend builds to static assets
2. Backend bundles to single Node.js file
3. Database migrations applied via Drizzle Kit
4. Static assets served by Express in production

The application uses a monorepo structure with shared TypeScript types and schemas, enabling type safety across the full stack while maintaining separation of concerns between frontend and backend code.

## Admin Panel Features

### Authentication
- **Login**: Username/password authentication for admin access
- **Default Credentials**: admin/admin123 (configurable in storage)
- **Session Management**: Simple token-based authentication

### Management Features
- **Order Management**: View all orders, update order status, manage payment status
- **Product Management**: View, edit, and delete products and categories
- **Contact Management**: View and respond to customer inquiries
- **Dashboard Overview**: Summary statistics for orders, products, and contacts

### Access
- **Admin Login**: Available at `/admin/login`
- **Admin Dashboard**: Available at `/admin/dashboard`
- **Quick Access**: Admin link in main navigation header

The admin panel provides a complete backend management system for the e-commerce platform, allowing easy management of all business operations.