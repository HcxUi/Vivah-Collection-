import { 
  categories, 
  products, 
  cartItems, 
  testimonials,
  orders,
  orderItems,
  contactRequests,
  adminUsers,
  type Category, 
  type Product, 
  type CartItem, 
  type Testimonial,
  type Order,
  type OrderItem,
  type ContactRequest,
  type AdminUser,
  type InsertCategory,
  type InsertProduct,
  type InsertCartItem,
  type InsertTestimonial,
  type InsertOrder,
  type InsertOrderItem,
  type InsertContactRequest,
  type InsertAdminUser,
  type ProductWithCategory,
  type CartItemWithProduct,
  type OrderWithItems
} from "@shared/schema";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  getProductsWithCategory(): Promise<ProductWithCategory[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Cart
  getCartItems(sessionId: string): Promise<CartItemWithProduct[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<void>;

  // Orders
  getOrders(): Promise<OrderWithItems[]>;
  getOrder(id: number): Promise<OrderWithItems | undefined>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  updatePaymentStatus(id: number, paymentStatus: string): Promise<Order | undefined>;

  // Contact Requests
  getContactRequests(): Promise<ContactRequest[]>;
  getContactRequest(id: number): Promise<ContactRequest | undefined>;
  createContactRequest(request: InsertContactRequest): Promise<ContactRequest>;
  updateContactRequestStatus(id: number, status: string): Promise<ContactRequest | undefined>;

  // Admin Users
  getAdminUsers(): Promise<AdminUser[]>;
  getAdminUser(id: number): Promise<AdminUser | undefined>;
  getAdminUserByUsername(username: string): Promise<AdminUser | undefined>;
  createAdminUser(user: InsertAdminUser): Promise<AdminUser>;
  updateAdminUser(id: number, user: Partial<InsertAdminUser>): Promise<AdminUser | undefined>;
  deleteAdminUser(id: number): Promise<boolean>;

  // Customers
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;

  // Testimonials
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  updateTestimonial(id: number, testimonial: Partial<InsertTestimonial>): Promise<Testimonial | undefined>;
  deleteTestimonial(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private testimonials: Map<number, Testimonial>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private contactRequests: Map<number, ContactRequest>;
  private adminUsers: Map<number, AdminUser>;
  private customers: Map<number, Customer>;
  private currentCategoryId: number;
  private currentProductId: number;
  private currentCartId: number;
  private currentTestimonialId: number;
  private currentOrderId: number;
  private currentOrderItemId: number;
  private currentContactRequestId: number;
  private currentAdminUserId: number;
  private currentCustomerId: number;

  constructor() {
    this.categories = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.testimonials = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.contactRequests = new Map();
    this.adminUsers = new Map();
    this.customers = new Map();
    this.currentCategoryId = 1;
    this.currentProductId = 1;
    this.currentCartId = 1;
    this.currentTestimonialId = 1;
    this.currentOrderId = 1;
    this.currentOrderItemId = 1;
    this.currentContactRequestId = 1;
    this.currentAdminUserId = 1;
    this.currentCustomerId = 1;

    this.initializeData();
  }

  private initializeData() {
    // Initialize categories
    const categoryData: InsertCategory[] = [
      { name: "Bridal Sarees", slug: "bridal-sarees", description: "Exquisite bridal sarees for your special day", image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=400&fit=crop" },
      { name: "Jewelry", slug: "jewelry", description: "Traditional and contemporary jewelry", image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=400&fit=crop" },
      { name: "Accessories", slug: "accessories", description: "Complete your bridal look", image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&h=400&fit=crop" },
    ];

    categoryData.forEach(cat => this.createCategory(cat));

    // Initialize admin user
    this.createAdminUser({
      username: "admin",
      email: "admin@vivahcollection.com",
      password: "admin123", // In production, this should be hashed
      role: "super_admin"
    });

    // Initialize sample orders
    this.createOrder({
      customerName: "Rajesh Kumar",
      customerEmail: "rajesh@email.com",
      customerPhone: "+91 9876543210",
      customerAddress: "123 Main Street, Mumbai, Maharashtra 400001",
      totalAmount: "125000",
      status: "pending",
      paymentStatus: "pending"
    }, [
      { productId: 1, quantity: 1, price: "125000" }
    ]);

    this.createOrder({
      customerName: "Priya Sharma",
      customerEmail: "priya@email.com",
      customerPhone: "+91 9876543211",
      customerAddress: "456 Park Avenue, Delhi, Delhi 110001",
      totalAmount: "85000",
      status: "confirmed",
      paymentStatus: "paid"
    }, [
      { productId: 2, quantity: 1, price: "85000" }
    ]);

    // Initialize sample contact requests
    this.createContactRequest({
      name: "Anita Patel",
      email: "anita@email.com",
      phone: "+91 9876543212",
      subject: "Custom Saree Design",
      message: "I would like to know about custom bridal saree designs for my wedding.",
      inquiryType: "custom_design",
      status: "new"
    });

    this.createContactRequest({
      name: "Meera Singh",
      email: "meera@email.com",
      subject: "Bulk Order Inquiry",
      message: "I need 10 sarees for a wedding function. Can you provide bulk pricing?",
      inquiryType: "bulk_order",
      status: "in_progress"
    });

    // Initialize products
    const productData: InsertProduct[] = [
      {
        name: "Royal Red Silk Saree",
        slug: "royal-red-silk-saree",
        description: "Pure silk saree with intricate gold zari work and traditional motifs. Perfect for weddings and special occasions.",
        price: "45000",
        originalPrice: "55000",
        categoryId: 1,
        images: [
          "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop"
        ],
        inStock: true,
        featured: true,
        fabric: "Pure Silk",
        color: "Red with Gold",
        size: "Free Size",
        careInstructions: "Dry clean only"
      },
      {
        name: "Golden Necklace Set",
        slug: "golden-necklace-set",
        description: "22k gold necklace set with kundan work and matching earrings. Handcrafted by skilled artisans.",
        price: "85000",
        originalPrice: "95000",
        categoryId: 2,
        images: [
          "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=600&fit=crop"
        ],
        inStock: true,
        featured: true,
        fabric: "22k Gold",
        color: "Gold",
        size: "Adjustable",
        careInstructions: "Store in jewelry box, avoid moisture"
      },
      {
        name: "Maroon Embroidered Saree",
        slug: "maroon-embroidered-saree",
        description: "Heavy embroidered saree with beadwork and sequins. Elegant maroon color with intricate patterns.",
        price: "35000",
        originalPrice: "40000",
        categoryId: 1,
        images: [
          "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=320",
          "https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=320"
        ],
        inStock: true,
        featured: true,
        fabric: "Georgette",
        color: "Maroon",
        size: "Free Size",
        careInstructions: "Dry clean only"
      },
      {
        name: "Bridal Accessories Set",
        slug: "bridal-accessories-set",
        description: "Complete bridal accessory collection including maang tikka, bangles, and traditional ornaments.",
        price: "25000",
        originalPrice: "30000",
        categoryId: 3,
        images: [
          "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1609794995011-6f7e5ccb1e7e?w=800&h=600&fit=crop"
        ],
        inStock: true,
        featured: true,
        fabric: "Mixed Materials",
        color: "Gold",
        size: "Standard",
        careInstructions: "Handle with care, store properly"
      },
      {
        name: "Emerald Green Silk Saree",
        slug: "emerald-green-silk-saree",
        description: "Stunning emerald green silk saree with gold border and traditional weaving patterns.",
        price: "42000",
        originalPrice: "48000",
        categoryId: 1,
        images: [
          "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=120",
          "https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=120"
        ],
        inStock: true,
        featured: false,
        fabric: "Pure Silk",
        color: "Emerald Green",
        size: "Free Size",
        careInstructions: "Dry clean only"
      },
      {
        name: "Diamond Earrings",
        slug: "diamond-earrings",
        description: "Elegant diamond drop earrings perfect for bridal occasions. Crafted with precision and care.",
        price: "65000",
        originalPrice: "75000",
        categoryId: 2,
        images: [
          "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop&contrast=1.2",
          "https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=800&h=600&fit=crop&contrast=1.2"
        ],
        inStock: true,
        featured: false,
        fabric: "Diamond & Gold",
        color: "White Gold",
        size: "Standard",
        careInstructions: "Clean with soft cloth, store carefully"
      },
      {
        name: "Traditional Bangles Set",
        slug: "traditional-bangles-set",
        description: "Set of traditional gold bangles with intricate designs. Perfect complement to any bridal outfit.",
        price: "28000",
        originalPrice: "32000",
        categoryId: 3,
        images: [
          "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&h=600&fit=crop&brightness=1.1",
          "https://images.unsplash.com/photo-1609794995011-6f7e5ccb1e7e?w=800&h=600&fit=crop&brightness=1.1"
        ],
        inStock: true,
        featured: false,
        fabric: "Gold Plated",
        color: "Gold",
        size: "Multiple Sizes",
        careInstructions: "Avoid water, store in dry place"
      },
      {
        name: "Pink Silk Saree",
        slug: "pink-silk-saree",
        description: "Delicate pink silk saree with silver work and floral motifs. Ideal for evening ceremonies.",
        price: "38000",
        originalPrice: "44000",
        categoryId: 1,
        images: [
          "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800&h=600&fit=crop&sat=2&hue=300",
          "https://images.unsplash.com/photo-1583391733956-6c78276477e5?w=800&h=600&fit=crop&sat=2&hue=300"
        ],
        inStock: true,
        featured: false,
        fabric: "Pure Silk",
        color: "Pink",
        size: "Free Size",
        careInstructions: "Dry clean only"
      }
    ];

    productData.forEach(product => this.createProduct(product));

    // Initialize testimonials
    const testimonialData: InsertTestimonial[] = [
      {
        name: "Priya Sharma",
        location: "Mumbai",
        content: "The saree I bought from Vivah Collection was absolutely stunning. The quality and craftsmanship exceeded my expectations. I felt like a true queen on my wedding day!",
        rating: 5,
        image: "https://images.unsplash.com/photo-1494790108755-2616b612b05b?w=150&h=150&fit=crop&crop=face"
      },
      {
        name: "Anita Patel",
        location: "Delhi",
        content: "Excellent service and beautiful collection. The team helped me choose the perfect jewelry set that complemented my saree perfectly. Highly recommended!",
        rating: 5,
        image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
      },
      {
        name: "Kavya Reddy",
        location: "Bangalore",
        content: "The attention to detail and quality of their products is unmatched. I got so many compliments on my wedding outfit. Thank you Vivah Collection for making my day special!",
        rating: 5,
        image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face"
      }
    ];

    testimonialData.forEach(testimonial => this.createTestimonial(testimonial));
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(cat => cat.slug === slug);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { 
      ...insertCategory, 
      id,
      description: insertCategory.description || null,
      image: insertCategory.image || null
    };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: number, updateData: Partial<InsertCategory>): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updatedCategory: Category = { ...category, ...updateData };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }

  async deleteCategory(id: number): Promise<boolean> {
    return this.categories.delete(id);
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(product => product.slug === slug);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.categoryId === categoryId);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.featured);
  }

  async getProductsWithCategory(): Promise<ProductWithCategory[]> {
    const products = Array.from(this.products.values());
    return products.map(product => ({
      ...product,
      category: product.categoryId ? this.categories.get(product.categoryId) || null : null
    }));
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { 
      ...insertProduct, 
      id, 
      createdAt: new Date(),
      description: insertProduct.description || null,
      originalPrice: insertProduct.originalPrice || null,
      categoryId: insertProduct.categoryId || null,
      images: insertProduct.images || null,
      inStock: insertProduct.inStock !== undefined ? insertProduct.inStock : true,
      featured: insertProduct.featured !== undefined ? insertProduct.featured : false,
      fabric: insertProduct.fabric || null,
      color: insertProduct.color || null,
      size: insertProduct.size || null,
      careInstructions: insertProduct.careInstructions || null
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct: Product = { ...product, ...updateData };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItemWithProduct[]> {
    const items = Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
    return items.map(item => ({
      ...item,
      product: item.productId ? this.products.get(item.productId) || null : null
    }));
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = Array.from(this.cartItems.values()).find(
      item => item.sessionId === insertItem.sessionId && item.productId === insertItem.productId
    );

    if (existingItem) {
      // Update quantity
      existingItem.quantity += insertItem.quantity || 1;
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    }

    const id = this.currentCartId++;
    const cartItem: CartItem = { 
      ...insertItem, 
      id, 
      createdAt: new Date(),
      productId: insertItem.productId || null,
      quantity: insertItem.quantity || 1
    };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;

    item.quantity = quantity;
    this.cartItems.set(id, item);
    return item;
  }

  async removeFromCart(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<void> {
    const itemsToRemove = Array.from(this.cartItems.values())
      .filter(item => item.sessionId === sessionId);
    
    itemsToRemove.forEach(item => this.cartItems.delete(item.id));
  }

  // Testimonials
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }

  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.currentTestimonialId++;
    const testimonial: Testimonial = { 
      ...insertTestimonial, 
      id,
      location: insertTestimonial.location || null,
      image: insertTestimonial.image || null,
      rating: insertTestimonial.rating || 5
    };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }

  async updateTestimonial(id: number, updateData: Partial<InsertTestimonial>): Promise<Testimonial | undefined> {
    const testimonial = this.testimonials.get(id);
    if (!testimonial) return undefined;
    
    const updatedTestimonial: Testimonial = { ...testimonial, ...updateData };
    this.testimonials.set(id, updatedTestimonial);
    return updatedTestimonial;
  }

  async deleteTestimonial(id: number): Promise<boolean> {
    return this.testimonials.delete(id);
  }

  // Orders
  async getOrders(): Promise<OrderWithItems[]> {
    const orders = Array.from(this.orders.values());
    return orders.map(order => ({
      ...order,
      items: Array.from(this.orderItems.values())
        .filter(item => item.orderId === order.id)
        .map(item => ({
          ...item,
          product: item.productId ? this.products.get(item.productId) || null : null
        }))
    }));
  }

  async getOrder(id: number): Promise<OrderWithItems | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    return {
      ...order,
      items: Array.from(this.orderItems.values())
        .filter(item => item.orderId === order.id)
        .map(item => ({
          ...item,
          product: item.productId ? this.products.get(item.productId) || null : null
        }))
    };
  }

  async createOrder(insertOrder: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const id = this.currentOrderId++;
    const order: Order = { 
      ...insertOrder, 
      id, 
      orderDate: new Date(),
      deliveryDate: insertOrder.deliveryDate || null,
      notes: insertOrder.notes || null,
      customerPhone: insertOrder.customerPhone || null,
      status: insertOrder.status || "pending",
      paymentStatus: insertOrder.paymentStatus || "pending"
    };
    this.orders.set(id, order);
    
    // Create order items
    items.forEach(item => {
      const itemId = this.currentOrderItemId++;
      const orderItem: OrderItem = { 
        ...item, 
        id: itemId, 
        orderId: id,
        productId: item.productId || null
      };
      this.orderItems.set(itemId, orderItem);
    });
    
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    order.status = status;
    this.orders.set(id, order);
    return order;
  }

  async updatePaymentStatus(id: number, paymentStatus: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    order.paymentStatus = paymentStatus;
    this.orders.set(id, order);
    return order;
  }

  // Contact Requests
  async getContactRequests(): Promise<ContactRequest[]> {
    return Array.from(this.contactRequests.values());
  }

  async getContactRequest(id: number): Promise<ContactRequest | undefined> {
    return this.contactRequests.get(id);
  }

  async createContactRequest(insertRequest: InsertContactRequest): Promise<ContactRequest> {
    const id = this.currentContactRequestId++;
    const request: ContactRequest = { 
      ...insertRequest, 
      id, 
      createdAt: new Date(),
      respondedAt: null,
      phone: insertRequest.phone || null,
      status: insertRequest.status || "new",
      inquiryType: insertRequest.inquiryType || "general"
    };
    this.contactRequests.set(id, request);
    return request;
  }

  async updateContactRequestStatus(id: number, status: string): Promise<ContactRequest | undefined> {
    const request = this.contactRequests.get(id);
    if (!request) return undefined;
    
    request.status = status;
    if (status === 'resolved') {
      request.respondedAt = new Date();
    }
    this.contactRequests.set(id, request);
    return request;
  }

  // Admin Users
  async getAdminUsers(): Promise<AdminUser[]> {
    return Array.from(this.adminUsers.values());
  }

  async getAdminUser(id: number): Promise<AdminUser | undefined> {
    return this.adminUsers.get(id);
  }

  async getAdminUserByUsername(username: string): Promise<AdminUser | undefined> {
    return Array.from(this.adminUsers.values()).find(user => user.username === username);
  }

  async createAdminUser(insertUser: InsertAdminUser): Promise<AdminUser> {
    const id = this.currentAdminUserId++;
    const user: AdminUser = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      lastLogin: null,
      role: insertUser.role || "admin"
    };
    this.adminUsers.set(id, user);
    return user;
  }

  async updateAdminUser(id: number, updateData: Partial<InsertAdminUser>): Promise<AdminUser | undefined> {
    const user = this.adminUsers.get(id);
    if (!user) return undefined;
    
    const updatedUser: AdminUser = { ...user, ...updateData };
    this.adminUsers.set(id, updatedUser);
    return updatedUser;
  }

  async deleteAdminUser(id: number): Promise<boolean> {
    return this.adminUsers.delete(id);
  }

  // Customer methods
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    return Array.from(this.customers.values()).find(customer => customer.email === email);
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const customer: Customer = { 
      id, 
      ...insertCustomer,
      createdAt: new Date(),
      lastLogin: null,
    };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, updateData: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const customer = this.customers.get(id);
    if (!customer) return undefined;
    
    const updatedCustomer: Customer = { ...customer, ...updateData };
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }

  async deleteCustomer(id: number): Promise<boolean> {
    return this.customers.delete(id);
  }
}

export const storage = new MemStorage();
